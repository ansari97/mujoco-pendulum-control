# Changelog – Universal Robots UR5e Description

All notable changes to this model will be documented in this file.

## [01/03/2023]
- Initial release.
